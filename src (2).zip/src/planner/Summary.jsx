import Destination from "./Destination";


const Summary = ({ plannerItem }) => {
    return (
        <Destination />
    )
}
export default Summary;