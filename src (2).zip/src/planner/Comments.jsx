const Comments = ({ plannerItem }) => {
    return (
        <div className="comments">
            <h3>댓글</h3>
        </div>
    );
};

export default Comments;